package com.threedaystartup.onme;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import android.app.ActionBar;
import android.app.Dialog;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ProgressBar;
import android.widget.Spinner;

public class MainActivity extends FragmentActivity implements
		ActionBar.TabListener {

	// My fields
	// used
	// http://www.androidhive.info/2013/07/android-expandable-list-view-tutorial/

	static ExpandableListAdapter listAdapter;
	static ExpandableListView expListView;
	static List<String> listOfBars;
	static HashMap<String, List<String>> drinksTable;

	// More of my fields
	static Button btnStartProgress;
	//static ProgressDialog progressBar;
	static int progressBarStatus = 0;
	static Handler progressBarHandler = new Handler();

	/**
	 * The {@link android.support.v4.view.PagerAdapter} that will provide
	 * fragments for each of the sections. We use a
	 * {@link android.support.v4.app.FragmentPagerAdapter} derivative, which
	 * will keep every loaded fragment in memory. If this becomes too memory
	 * intensive, it may be best to switch to a
	 * {@link android.support.v4.app.FragmentStatePagerAdapter}.
	 */
	SectionsPagerAdapter mSectionsPagerAdapter;

	/**
	 * The {@link ViewPager} that will host the section contents.
	 */
	ViewPager mViewPager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Set up the action bar.
		final ActionBar actionBar = getActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
		actionBar.setDisplayShowHomeEnabled(false);
		actionBar.setDisplayShowTitleEnabled(false);

		// Create the adapter that will return a fragment for each of the two
		// primary sections of the app.
		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager());

		// Set up the ViewPager with the sections adapter.
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);

		// When swiping between different sections, select the corresponding
		// tab. We can also use ActionBar.Tab#select() to do this if we have
		// a reference to the Tab.
		mViewPager
				.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
					@Override
					public void onPageSelected(int position) {
						actionBar.setSelectedNavigationItem(position);
					}
				});

		// For each of the sections in the app, add a tab to the action bar.
		for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
			// Create a tab with text corresponding to the page title defined by
			// the adapter. Also specify this Activity object, which implements
			// the TabListener interface, as the callback (listener) for when
			// this tab is selected.
			actionBar.addTab(actionBar.newTab()
					.setText(mSectionsPagerAdapter.getPageTitle(i))
					.setTabListener(this));
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onTabSelected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
		// When the given tab is selected, switch to the corresponding page in
		// the ViewPager.
		mViewPager.setCurrentItem(tab.getPosition());
	}

	@Override
	public void onTabUnselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	@Override
	public void onTabReselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	/**
	 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
	 * one of the sections/tabs/pages.
	 */
	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			// getItem is called to instantiate the fragment for the given page.
			// Return a DummySectionFragment (defined as a static inner class
			// below) with the page number as its lone argument.
			Fragment fragment;
			if (position == 0)
				fragment = new RedeemSectionFragment();
			else
				fragment = new SendSectionFragment();
			Bundle args = new Bundle();
			return fragment;
		}

		@Override
		public int getCount() {
			// Show 3 total pages.
			return 2;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			Locale l = Locale.getDefault();
			switch (position) {
			case 0:
				return getString(R.string.title_section1).toUpperCase(l);
			case 1:
				return getString(R.string.title_section2).toUpperCase(l);
			}
			return null;
		}
	}

	/**
	 * A dummy fragment representing a section of the app, but that simply
	 * displays dummy text.
	 */
	public static class RedeemSectionFragment extends Fragment {
		/**
		 * The fragment argument representing the section number for this
		 * fragment.
		 */

		View rootView;

		public RedeemSectionFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			rootView = inflater.inflate(R.layout.fragment_main_redeem,
					container, false);

			// get the listview
			expListView = (ExpandableListView) rootView
					.findViewById(R.id.expandableListView);

			// preparing list data
			initializeDrinksData();

			listAdapter = new ExpandableListAdapter(rootView.getContext(),
					listOfBars, drinksTable);

			// setting list adapter
			expListView.setAdapter(listAdapter);

			// Listview on child click listener
			expListView.setOnChildClickListener(new OnChildClickListener() {

				@Override
				public boolean onChildClick(ExpandableListView parent, View v,
						final int barPosition, final int drinkPosition,
						long id) {

					// custom dialog
					final Dialog dialog = new Dialog(rootView.getContext());
					dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
					dialog.setContentView(R.layout.dialog_redeem);
					dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

					Button dialogConfirmButton = (Button) dialog
							.findViewById(R.id.dialogConfirmButton);
					// if button is clicked, close the custom dialog
					dialogConfirmButton
							.setOnClickListener(new OnClickListener() {
								@Override
								public void onClick(View v) {
									dialog.dismiss();

									final Dialog progressDialog = new Dialog(rootView.getContext());
									progressDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
									progressDialog.setContentView(R.layout.dialog_progressbar);
									final ProgressBar progressBar = (ProgressBar) progressDialog.findViewById(R.id.progressBar);
									progressBar.setProgress(0);
									progressBar.setMax(60);
									progressDialog.setCancelable(false);
									progressDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
									progressDialog.show();

									// reset progress bar status
									progressBarStatus = 0;

									new Thread(new Runnable() {
										public void run() {
											while (progressBarStatus < 60) {

												// process some tasks
												progressBarStatus++;

												// your computer is too fast,
												// sleep 1 second
												try {
													Thread.sleep(100);
												} catch (InterruptedException e) {
													e.printStackTrace();
												}

												// Update the progress bar
												progressBarHandler
														.post(new Runnable() {
															public void run() {
																progressBar
																		.setProgress(progressBarStatus);
															}
														});
											}

											if (progressBarStatus >= 60)
												progressDialog.dismiss();
										}
									}).start();

									updateDrinks(barPosition,drinkPosition);
									
									listAdapter.notifyDataSetChanged();
								}
							});

					Button dialogCancelButton = (Button) dialog
							.findViewById(R.id.dialogCancelButton);
					// if button is clicked, close the custom dialog
					dialogCancelButton
							.setOnClickListener(new OnClickListener() {
								@Override
								public void onClick(View v) {
									dialog.dismiss();
								}
							});

					dialog.show();

					return false;
				}
			});

			return rootView;
		}

		/*
		 * Preparing the list data
		 */
		private void initializeDrinksData() {
			initializeListOfBars();
			initializeTableForDrinks();	
		}
		
		private void initializeListOfBars(){
			listOfBars = new ArrayList<String>();
			listOfBars.add("Ruloff's");
			listOfBars.add("Level B");						
			listOfBars.add("Dunbar's");
		}
		
		private void initializeTableForDrinks(){
			drinksTable= new HashMap<String, List<String>>();
			List<String> top250 = new ArrayList<String>();
			top250.add("Beer");
			top250.add("Beer");
			top250.add("Tequila Shots");
			drinksTable.put(listOfBars.get(0), top250); // Header, Child, data

			List<String> nowShowing = new ArrayList<String>();
			nowShowing.add("Wine");
			nowShowing.add("Wine");
			nowShowing.add("Wings");
			nowShowing.add("Beer");
			drinksTable.put(listOfBars.get(1), nowShowing);

			List<String> comingSoon = new ArrayList<String>();
			comingSoon.add("Jaeger Bombz");
			comingSoon.add("Saki Bomb");
			comingSoon.add("Bloody Mary");
			drinksTable.put(listOfBars.get(2), comingSoon);
		}
		
		private void updateDrinks(int barPosition, int drinkPosition){
			//remove the drink from the list of drinks
			drinksTable.get(
					listOfBars.get(barPosition))
					.remove(drinkPosition);
			
			//replace the new list of drinks in the drinks table
			drinksTable.put(listOfBars
					.get(barPosition), drinksTable
					.get(listOfBars
							.get(barPosition)));
		}
	}

	/**
	 * A dummy fragment representing a section of the app, but that simply
	 * displays dummy text.
	 */
	public static class SendSectionFragment extends Fragment {
		/**
		 * The fragment argument representing the section number for this
		 * fragment.
		 */

		public SendSectionFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main_send,
					container, false);

			List<String> spinnerArray = new ArrayList<String>();
			spinnerArray.add("Ithaca");
			spinnerArray.add("Syracuse");
			ArrayAdapter<String> adapter = new ArrayAdapter<String>(
					rootView.getContext(),
					android.R.layout.simple_spinner_item, spinnerArray);
			adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			Spinner Items = (Spinner) rootView
					.findViewById(R.id.locationSpinner);
			Items.setAdapter(adapter);

			List<String> spinnerArray2 = new ArrayList<String>();
			spinnerArray2.add("Ruloff's");
			spinnerArray2.add("Dunbars");
			spinnerArray2.add("Level B");
			spinnerArray2.add("Loco");
			spinnerArray2.add("Chapter House");
			ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(
					rootView.getContext(),
					android.R.layout.simple_spinner_item, spinnerArray2);
			adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			Spinner Items2 = (Spinner) rootView
					.findViewById(R.id.establishmentSpinner);
			Items2.setAdapter(adapter2);

			List<String> spinnerArray3 = new ArrayList<String>();
			spinnerArray3.add("Craft Beer");
			spinnerArray3.add("Domestic Beer");
			spinnerArray3.add("Tequila Shot");
			spinnerArray3.add("Wine");
			ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(
					rootView.getContext(),
					android.R.layout.simple_spinner_item, spinnerArray3);
			adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			Spinner Items3 = (Spinner) rootView.findViewById(R.id.drinkSpinner);
			Items3.setAdapter(adapter3);
			return rootView;
		}
	}

}

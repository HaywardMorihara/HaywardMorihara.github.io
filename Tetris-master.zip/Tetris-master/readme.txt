link to site:
http://psnbtech.blogspot.com/2012/10/tutorial-java-tetris-game.html